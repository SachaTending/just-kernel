#ifndef __packed
#define __packed __attribute__((packed))
#endif