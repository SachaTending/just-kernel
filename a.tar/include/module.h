#ifndef _MODULE_H
#define _MODULE_H

#define MODULE_START_CALL __attribute__((constructor))

#endif