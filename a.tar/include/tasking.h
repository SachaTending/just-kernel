#pragma once

void kernel_idle_task(void);