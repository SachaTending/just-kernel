#pragma once
#include "stdint.h"

void PitWait(uint ms);